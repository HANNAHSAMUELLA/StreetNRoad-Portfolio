# Screenshot assets

Place only reviewed, sanitized screenshots in this folder.

Suggested filenames:
- `streetnroad-homepage.png`
- `business-profile.png`
- `business-dashboard.png`
- `sample-invoice-workflow.png`
- `sample-receipt-verification.png`
- `delivery-tracking-demo.png`

Use fictional demo data. Remove real customer information, phone numbers, email addresses, QR codes tied to live records, account identifiers, internal URLs and browser/session information before adding images.

No production screenshots have been included in this starter portfolio.
